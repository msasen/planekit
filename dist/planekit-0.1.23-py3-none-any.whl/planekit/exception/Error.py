# define Python user-defined exceptions
class Error(Exception):
    """Sorry, a problem occurred"""
    pass
