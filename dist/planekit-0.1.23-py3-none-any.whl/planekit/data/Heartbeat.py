class Heartbeat:
    def __init__(self, message=None):
        if message is None:
            self.all = message
        else:
            self.all = message
